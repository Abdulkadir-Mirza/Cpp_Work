//Abdulkadir Mirza --- C++ Program to implement a basic input and output.
#include<iostream>
using namespace std;


//MAIN
int main(){
int i;
cout << "Enter a number:" << "\n";
cin >> i;

cout << i <<  " squared is: " << i*i << "\n";
return 0;
}
