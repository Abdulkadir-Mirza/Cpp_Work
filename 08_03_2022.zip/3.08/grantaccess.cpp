//Abdulkadir Mirza --- Granting access to derived class
//Error
#include<iostream>
using namespace std;

class XYZ{
    int m;
    public:
    void 
};

class ABC : private XYZ{

};

int main(){

    return 0;
}